#include <iostream>
#include <cmath>

using namespace std;

int main() {
   int ids[100]
   string names[100];
   int scores[100];
   int count, total = 0, num_students;
   double avg, std_dev;

   cout << "To calculate class average enter number of students: ";
   cin >> num_students;

   for (count = 0; count < num_students; count++) {
      cout << "Enter id for student " << count + 1 << ": ";
      cin >> ids[count];
      cout << "Enter name for student " << count + 1 << ": ";
      cin >> names[count];
      cout << "Enter score for student " << count + 1 << ": ";
      cin >> scores[count];
      total += scores[count];
   }
   avg = ((double) total) / num_students;
   cout << "Average score = " << avg << endl;

   std_dev = 0;
   for (count = 0; count < num_students; count++) {
      std_dev += pow(scores[count] - avg, 2);
   }
   std_dev /= count;
   std_dev = sqrt(std_dev);
   cout << "Std deviation = " << std_dev << endl;

   cout << "Students with score below average:" << endl;
   for (count = 0; count < num_students; count++) {
      if (scores[count] < avg)
         cout << names[count] << endl;
   }

   return 0;
}
